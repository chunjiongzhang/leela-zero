import y
import globalvar as gl
a=gl.get_value('aa')

print(2*a)
pause
