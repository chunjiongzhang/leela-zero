import globalvar as gl 
gl._init() 
gl.set_value('BLOCKS', 5) 
gl.set_value('FILTERS', 64) 
gl.set_value('LEARNINGRATE', 0.03) 
gl.set_value('ENDSTEP',000) 
